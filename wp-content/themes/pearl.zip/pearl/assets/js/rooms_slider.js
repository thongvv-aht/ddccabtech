'use strict';

(function ($) {
    'use strict';

    var slider = $('.stm-rooms-slider');
    slider.owlCarousel({
        dots: false,
        items: 1,
        loop: true,
        nav: true
    });
})(jQuery);