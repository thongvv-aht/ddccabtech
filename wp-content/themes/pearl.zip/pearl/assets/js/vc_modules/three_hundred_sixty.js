'use strict';

jQuery(document).ready(function ($) {
    "use strict";

    $('#myTurntable').turntable({
        axis: 'x',
        scrollStart: 'middle'
    });
});