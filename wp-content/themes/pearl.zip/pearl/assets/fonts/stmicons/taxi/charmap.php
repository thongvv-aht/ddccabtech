<?php $icons = array();
$icons['stmicons']['help'] = array("class"=>'help',"tags"=>'help');
$icons['stmicons']['like'] = array("class"=>'like',"tags"=>'like');
$icons['stmicons']['pie-chart'] = array("class"=>'pie-chart',"tags"=>'pie-chart');
$icons['stmicons']['security'] = array("class"=>'security',"tags"=>'security');
$icons['stmicons']['car-basic'] = array("class"=>'car-basic',"tags"=>'car-basic');
$icons['stmicons']['car-standard'] = array("class"=>'car-standard',"tags"=>'car-standard');
$icons['stmicons']['car-business'] = array("class"=>'car-business',"tags"=>'car-business');
$icons['stmicons']['quote'] = array("class"=>'quote',"tags"=>'quote');