<?php $icons = array();
$icons['stmicons']['pencil'] = array("class"=>'pencil',"tags"=>'pencil');